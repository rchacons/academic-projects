package fr.istic.csr.gare.v1;

import fr.istic.csr.gare.v1.elements.GareV1;

public class MainV1  {
    public static void main(String[] args) {
        new GareV1();
    }
}
